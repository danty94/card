// React core
import React, { Component } from 'react';

class Game extends Component {

  render() {
    return (
      <section className="Game">
        Welcome!
      </section>
    )
  }

}

export default Game;
